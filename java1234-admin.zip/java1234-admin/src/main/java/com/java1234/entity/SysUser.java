package com.java1234.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * @TableName sys_user
 */
@TableName(value ="sys_user")
@Data
public class SysUser extends BaseEntity implements Serializable {

    /**
     * 用户名
     */
    @TableField(value = "username")
    private String username;

    /**
     * 密码
     */
    @TableField(value = "password")
    private String password;

    /**
     * 用户头像
     */
    @TableField(value = "avatar")
    private String avatar;

    /**
     * 用户邮箱
     */
    @TableField(value = "email")
    private String email;

    /**
     * 手机号码
     */
    @TableField(value = "phonenumber")
    private String phonenumber;

    /**
     * 最后登录时间
     */
    @TableField(value = "login_date")
    @JsonFormat(pattern ="yyyy-MM-dd HH:mm:ss")
    private Date loginDate;

    /**
     * 帐号状态（0正常 1停用）
     */
    @TableField(value = "status")
    private String status;
    /**
     * 所属角色
     */
    @TableField(exist = false)
    private String roles;
    /**
     * 确认新密码
     */
    @TableField(exist = false)
    private String newPassword;

    /**
     * 旧密码（前端传来的）
     */
    @TableField(exist = false)
    private String oldPassword;
    /**
     * 所有角色集合
     */
    @TableField(exist = false)
    private List<SysRole> sysRoleList;
    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}