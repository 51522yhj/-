package com.java1234.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {

 /*   @Autowired
    private SysUserService sysUserService;

    @GetMapping("/user/list")
     @PreAuthorize("hasAnyAuthority('system2:user:list')")
    //@PreAuthorize("hasRole('ROLE2_common')")
    public R userList(@RequestHeader(required = false) String token){
        if(StringUtil.isNotEmpty(token)){
            Map<String,Object> resutMap=new HashMap<>();
            List<SysUser> userList = sysUserService.list();
            resutMap.put("userList",userList);
            return R.ok(resutMap);
        }else{
            return R.error(401,"没有权限访问");
        }
    }

    @PostMapping("/login")
    public R login(){
        String token= JwtUtils.genJwtToken("java1234");
        return R.ok().put("token",token);
    }
*/
}
