package com.java1234.mapper;

import com.java1234.entity.SysRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author h'h
* @description 针对表【sys_role】的数据库操作Mapper
* @createDate 2024-06-25 21:20:34
* @Entity com.java1234.entity.SysRole
*/
@Mapper
public interface SysRoleMapper extends BaseMapper<SysRole> {

}




